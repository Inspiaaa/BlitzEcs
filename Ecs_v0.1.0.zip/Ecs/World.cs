using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace Ecs {
    public class World {
        private Dictionary<Type, IComponentPool> componentPoolsByType;

        private Stack<int> recycledEntities;
        private int entityCount;

        public World() {
            componentPoolsByType = new Dictionary<Type, IComponentPool>();
            recycledEntities = new Stack<int>();
            entityCount = 0;
        }

        public Entity Spawn() {
            int id = 0;

            if (recycledEntities.Count > 0) {
                id = recycledEntities.Pop();
            }
            else {
                id = entityCount;
                entityCount ++;
            }
            return new Entity(this, id);
        }

        public void Despawn(Entity entity) {
            foreach (IComponentPool pool in componentPoolsByType.Values) {
                pool.Remove(entity.Id);
            }
            recycledEntities.Push(entity.Id);
        }

        public ComponentPool<TComponent> GetComponentPool<TComponent>() where TComponent : struct {
            Type type = typeof(TComponent);
            if (componentPoolsByType.TryGetValue(type, out IComponentPool pool)) {
                return (ComponentPool<TComponent>)pool;
            }

            ComponentPool<TComponent> newPool = new ComponentPool<TComponent>();
            componentPoolsByType[type] = newPool;
            return newPool;
        }

        internal bool TryGetIComponentPool(Type componentType, out IComponentPool pool) {
            return componentPoolsByType.TryGetValue(componentType, out pool);
        }
    }
}
